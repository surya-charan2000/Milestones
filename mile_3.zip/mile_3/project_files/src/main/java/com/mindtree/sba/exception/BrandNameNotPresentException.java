package com.mindtree.sba.exception;

public class BrandNameNotPresentException extends RuntimeException {

    public BrandNameNotPresentException(String message) {
        super(message);
    }
}
