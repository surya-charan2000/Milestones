package com.mindtree.sba;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbaApplicationTests {

	@Test
	void contextLoads() {
	}

}
