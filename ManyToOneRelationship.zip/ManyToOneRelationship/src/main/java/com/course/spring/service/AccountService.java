package com.course.spring.service;

import java.util.List;

import com.course.spring.models.Account;

public interface AccountService {

	public List<Account> getAllAccounts();
	public Account getAccountById(int id);
	public void addAccount(Account acc);
	public void updateAccount(Account acc);
}
