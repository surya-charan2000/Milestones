package com.course.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.course.spring.models.Account;
import com.course.spring.service.AccountService;
import com.course.spring.service.AccountServiceImpl;

@RestController
@RequestMapping("/accounts")
public class AccountController {
	
	@Autowired
	private AccountService accountService;
	
	@GetMapping()
	public List<Account> getAllAccounts() {	
		return accountService.getAllAccounts();
	}
	
	@GetMapping("{id}")
	public Account getAccount(@PathVariable int id) {
		return accountService.getAccountById(id);
	}
	
	@PostMapping()
	public boolean addAccount(@RequestBody Account acc) {
		accountService.addAccount(acc);
		return true;
	}
	
}
