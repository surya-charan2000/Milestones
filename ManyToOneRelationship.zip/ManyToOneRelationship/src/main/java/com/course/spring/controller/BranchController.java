package com.course.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.course.spring.models.Branch;
import com.course.spring.service.BranchService;

@RestController
@RequestMapping("/branches")
public class BranchController {
	
	@Autowired
	BranchService branchService;
	
	@PostMapping()
	public void addBranch(@RequestBody Branch branch) {
		branchService.addBranch(branch);
	}
	
}
