package com.course.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.course.spring.models.Branch;
import com.course.spring.respository.BranchRepository;

@Service
public class BranchServiceImpl implements BranchService{

	@Autowired
	private BranchRepository branchRepository;
	
	@Override
	public void addBranch(Branch branch) {
		branchRepository.save(branch);
	}

}
