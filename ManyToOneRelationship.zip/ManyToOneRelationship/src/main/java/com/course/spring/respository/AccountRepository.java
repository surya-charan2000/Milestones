package com.course.spring.respository;

import org.springframework.data.repository.CrudRepository;

import com.course.spring.models.Account;

public interface AccountRepository extends CrudRepository<Account,Integer>{

}
