package com.course.spring.respository;

import org.springframework.data.repository.CrudRepository;

import com.course.spring.models.Branch;

public interface BranchRepository extends CrudRepository<Branch,Integer>{

}
