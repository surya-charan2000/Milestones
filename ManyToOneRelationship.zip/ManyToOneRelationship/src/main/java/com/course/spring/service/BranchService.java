package com.course.spring.service;

import com.course.spring.models.Branch;

public interface BranchService {
	public void addBranch(Branch branch);
}
