package com.course.spring.models;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Branch {

	@Id
	private int id;
	private String branchName;
	private String branchCode;
	public Branch(int id, String branchName, String branchCode) {
		super();
		this.id = id;
		this.branchName = branchName;
		this.branchCode = branchCode;
	}
	public Branch() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	
	
}
