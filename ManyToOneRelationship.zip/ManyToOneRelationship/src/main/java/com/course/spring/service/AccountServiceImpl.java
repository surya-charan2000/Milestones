package com.course.spring.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.course.spring.models.Account;
import com.course.spring.respository.AccountRepository;

@Service
public class AccountServiceImpl implements AccountService{

	@Autowired
	AccountRepository accountRepository;
	
	private List<Account> list=new ArrayList<Account>();
	
	@Override
	public List<Account> getAllAccounts() {
		list.removeAll(list);
		Iterator<Account> it=accountRepository.findAll().iterator();
		while(it.hasNext()) {
			list.add(it.next());
		}
		return list;
	}

	@Override
	public Account getAccountById(int id) {
		return accountRepository.findById(id).get();
	}

	@Override
	public void addAccount(Account acc) {
		accountRepository.save(acc);
	}

	@Override
	public void updateAccount(Account acc) {
		accountRepository.save(acc);
	}

}
